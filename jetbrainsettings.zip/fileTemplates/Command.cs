using FinFactory.Abstractions.Application.MediatR.Commands;

namespace #[[names]]
{
    public class `(+yas/filename)`
    : Command<`(+yas/filename)`Result>
    {
    }
}
